package LWP::DebugFile;

our $VERSION = '6.31';

# legacy stub

1;
